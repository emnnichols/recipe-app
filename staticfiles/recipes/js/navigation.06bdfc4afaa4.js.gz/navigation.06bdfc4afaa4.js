function showMenu() {
  const nav = document.getElementById("nav")
  nav.classList.toggle("nav-hide");
  nav.classList.toggle("nav-show");
}